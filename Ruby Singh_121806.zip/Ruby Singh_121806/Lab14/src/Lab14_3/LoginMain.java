package Lab14_3;

import java.util.Scanner;

public class LoginMain {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Username:");
		String username=sc.next();
		System.out.println("Enter Password:");
		String password=sc.next();
		Login login = (usernam,passwor)->{
			if(usernam.equals("ruby") && passwor.equals("ruby"))
			{
				return true;
			}
			else 
				return false;
			
		};
		boolean flag = login.validate(username, password);
		if(flag){
			System.out.println("Login successful");
			}
		
	else{
		System.out.println("Invalid Crendiatials");
	}
sc.close();
}

}
