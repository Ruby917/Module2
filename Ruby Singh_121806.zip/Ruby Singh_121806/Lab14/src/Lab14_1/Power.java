package Lab14_1;

@FunctionalInterface
public interface Power {
	public double power(double x,double y);
}
