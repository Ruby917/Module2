import java.util.ArrayList;
import java.util.List;


public class EmployeeRepository {
private static List<Employee> employeeList;
private static List<Department> departmentList;	


	static {
		prepareEmployeeList();
		prepareDepartmentList();
	}
	
	private static void prepareEmployeeList() {
		employeeList = new ArrayList<>();
		employeeList.add(new Employee(1,"vandana","Nagpal","van@gmail.com",
				"8007919296","Manager",60000,100));
		
		employeeList.add(new Employee(2,"saras","Jeswani","van@gmail.com",
				"8007919296","SoftwareEngg",30000,101));
		
		employeeList.add(new Employee(3,"ruby","Singh","van@gmail.com",
				"8007919296","Senior Manager",50000,102));
		
		employeeList.add(new Employee(4,"shikha","Pandey","van@gmail.com",
				"8007919296","SoftwareAssociate",90000,103));
		
		employeeList.add(new Employee(5,"parth","Valangar","van@gmail.com",
				"8007919296","Consultant",30000,104));
		
		
		
	}
	
	private static void prepareDepartmentList()
	{
		departmentList=new ArrayList<>();
		departmentList.add(new Department(10,"Computer",100));
		departmentList.add(new Department(20,"IT",101));
		departmentList.add(new Department(20,"IT",102));
		departmentList.add(new Department(20,"IT",103));
		departmentList.add(new Department(30,"Electricals",102));
		departmentList.add(new Department(40,"Electronics",103));
		departmentList.add(new Department(50,"Mechanics",104));
	}

	public static List<Employee> getEmployeeList() {
		return employeeList;
	}
	public static List<Department> getDepartmentList()
	{
		return departmentList;
	}
}
