
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class EmployeeService {
	public static void main(String[] args) {
		/*System.out.println("Employee count in every Department");
		Map<String,List<Employee>> empCount = EmployeeRepository.getEmployeeList().stream().collect(Collectors.groupingBy((departmentId)->));
		for(String city:cityCount.keySet()) {
			System.out.println(city+":"+cityCount.get(city).size());
		}
		printLine();*/
		//sort the Employee by Firstname
				printLine();
				System.out.println("Sorted List of Employees by FirstName");
				//create a comparable lambda which we will use for sorting
				Comparator<Employee> nameComparator = (cand1,cand2)->cand1.getFirstName().compareTo(cand2.getFirstName());
				//pass the comparator in sorted() method of stream
				EmployeeRepository.getEmployeeList().stream().sorted(nameComparator).forEach(System.out::println);
		
				
				
				//sort the Employee by Employee ID
				printLine();
				System.out.println("Sorted List of Employees by Employee Id");
				//create a comparable lambda which we will use for sorting
				Comparator<Employee> yearComparator = (cand1,cand2)->cand1.getEmployeeId()-cand2.getEmployeeId();
				//pass the comparator in sorted() method of stream
			EmployeeRepository.getEmployeeList().stream().sorted(yearComparator).forEach(System.out::println);
				
				
				
				
				
			
				
				
				
				//Listing Department with Highest Count of Employees
				Integer maxYear = EmployeeRepository.getDepartmentList().stream().map((candidate)->candidate.getManagerId()).max(Integer::compare).get();
				List<Department> seniors = EmployeeRepository.getDepartmentList().stream().filter((candidate)->candidate.getManagerId()==maxYear).collect(Collectors.toList());
				System.out.println("Department with Highest Count of Employees");
				seniors.forEach(System.out::println);
		
		
	}
	
	private static void printLine() {
		
		System.out.println("-----------------------------------------");
	}
}
