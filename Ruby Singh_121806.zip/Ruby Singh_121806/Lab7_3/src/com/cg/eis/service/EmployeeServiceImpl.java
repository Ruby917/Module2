	package com.cg.eis.service;

import java.util.HashMap;
import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class EmployeeServiceImpl implements EmployeeService {
	HashMap<Integer,Employee> list = new HashMap<Integer,Employee>();
	public void addEmployee() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of employees: ");
		int n = sc.nextInt();
		for(int i=1;i<=n;i++){
			System.out.println("Enter the Id of employee "+i+" : ");
			int id1 = sc.nextInt();
			System.out.println("Enter the Name of employee "+i+" : ");
			String name = sc.next();
			System.out.println("Enter the Salary of employee "+i+" : ");
			double salary = sc.nextDouble();
			System.out.println("Enter the Designation of employee "+i+" : ");
			String designation = sc.next();
			Employee e = new Employee(name,salary,designation);
			list.put(id1,e);
			showScheme(e);	
		}
		
		/*boolean loopAgain = true;
		do{
			Employee e;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Id: ");
		int id = sc.nextInt();
		System.out.println("Enter the Name: ");
		String name = sc.next();
		System.out.println("Enter the Salary: ");
		int salary = sc.nextInt();
		System.out.println("Enter the Designation: ");
		String designation = sc.next();
		e = new Employee(name,salary,designation);
		list = new HashMap<Integer,Employee>();
		Employee oldValue = list.put(id,e);
		showScheme(e);
		if(oldValue!=null){
			System.out.println("hello");
		}
		System.out.println("Enter Anothe Employee Details:(y/n)");
		String ans = sc.nextLine();
		if(ans.equals("y")||ans.equals("Y")){
			continue;
		}else{
			break;
		}
		}while(loopAgain);*/
		
		/*Employee emp1,emp2,emp3;
		list = new HashMap<Integer,Employee>();
		emp1 = new Employee("Ruby",19000,"System Associate");
		emp2 = new Employee("Rohit",40000,"Manager");
		emp3 = new Employee("Riya",35000,"Programmer");
		list.put(101,emp1);
		showScheme(emp1);
		list.put(102,emp2);
		showScheme(emp2);
		list.put(103,emp3);
		showScheme(emp3);
		System.out.println("HashMap created ");*/
	}
	public void showScheme(Employee e) {
		if((e.salary>5000 && e.salary<20000) && e.designation.equals("System Associate")){
			e.insuranceScheme = "Scheme C";
		}
		else if((e.salary>=20000 && e.salary<40000) && e.designation.equals("Programmer")){
			e.insuranceScheme = "Scheme B";		
			}
		else if(e.salary>=40000 && e.designation.equals("Manager")){
			e.insuranceScheme = "Scheme A";			
			}
		else if(e.salary<5000 && e.designation.equals("Clerk")){
			e.insuranceScheme = "No Scheme";			
			}
		else{
			System.out.println("Invalid Input");
		}
		
	}
	public void displayDetails() {
		System.out.println("");
		System.out.println("-------Employee Details-----");
		System.out.println("EmpId EmpName Salary Designation Scheme");
		for(int id:list.keySet()){
			System.out.println(id+" "+list.get(id));
			
		}
		
	
	list.remove(102);
	System.out.println("After Deletion ");
	System.out.println("EmpId EmpName Salary Designation Scheme");
	for(int id:list.keySet()){
		System.out.println(id+" "+list.get(id));
		
	}
	}
}
