package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeServiceImpl;

public class EmployeeMain {
	public static void main(String[] args) {
		EmployeeServiceImpl sc = new EmployeeServiceImpl();
		sc.addEmployee();
		sc.displayDetails();
	}
	
	
	

}
