package Lab3;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class Lab3_6 {
	public static void main(String[] args) {        
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter zoneid");
		String zoneId = sc.nextLine();
		ZonedDateTime currentTime = ZonedDateTime.now(ZoneId.of(zoneId));
		System.out.println("Current Date and Time in This Time Zone is: "+currentTime);
	}

}
