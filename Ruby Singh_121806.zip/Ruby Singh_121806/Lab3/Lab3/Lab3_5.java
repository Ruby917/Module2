package Lab3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Lab3_5 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the purchase date: ");
		String pdate= sc.nextLine();
		System.out.println("Enter the warrantee in months and years: ");
		long mon= sc.nextLong();
		long yr = sc.nextLong();
		calExpireDate(pdate,mon,yr);
	}
public static void calExpireDate(String pdate,long mon,long yr){
	DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	LocalDate purchaseDate = LocalDate.parse(pdate,format);
	LocalDate addmonths = purchaseDate.plusMonths(mon);
	LocalDate addyear = purchaseDate.plusYears(yr);
	System.out.println("The expiry date of the product is: "+"-"+addmonths.getMonth()+"-"+addyear.getYear());
}

}
