package Lab6.Lab6_1;

public class Person {
	String firstName;
	String lastName;
	char gender;
	public String getFirstName() {
		return firstName;
	}
	              
	public Person() {
		super();
	}
	public Person(String firstName, String lastName, char gender) throws BlankNameException{
		super();
		if(firstName.length()!=0){
			this.firstName = firstName;	
		}else{
			throw new BlankNameException("first name must be entered");

		}
		if(lastName.length()!=0){
			
			this.lastName = lastName;
		}else{
			throw new BlankNameException("last name must be entered");
		}
		this.gender = gender;
	}
	public void setFirstName(String firstName) throws BlankNameException{
		if(firstName.length()!=0){
			this.firstName = firstName;	

		}else{
			throw new BlankNameException("first name must be entered");

		}
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) throws BlankNameException{
		if(lastName.length()!=0){
			this.lastName = lastName;

		}else{
			throw new BlankNameException("last name must be entered");

		}
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}

}
