package Lab6.Lab6_2;

public class AgeException extends Exception {
	public AgeException(String msg){
		super(msg);
	}

}
