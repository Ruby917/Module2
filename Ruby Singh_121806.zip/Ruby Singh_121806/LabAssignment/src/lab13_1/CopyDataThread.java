package lab13_1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyDataThread extends Thread {
	FileInputStream fromFile;
	FileOutputStream toFile;
	public CopyDataThread(FileInputStream fromFile, FileOutputStream toFile) {
		this.fromFile=fromFile;
		this.toFile=toFile;
		
	}

	public void run(){
		
		try {
			int k;
			int count=0;
			
			while((k=fromFile.read())!=-1){
				
				toFile.write((char)k);
				count++;
				if(count==10){
					System.out.println("10 Characters Copied !");
					Thread.sleep(5000);
					count=0;
				}
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}


}

