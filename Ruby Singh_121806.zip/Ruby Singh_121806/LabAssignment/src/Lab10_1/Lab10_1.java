package Lab10_1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;

public class Lab10_1 {
	public static void main(String[] args) {
		Properties prop = new Properties();
		InputStream in = null;
		try {
			in = new FileInputStream("D:\\MODULE_2\\practice programs\\LabAssignment\\src\\Lab10_1\\PersonProps.properties");
			try {
				prop.load(in);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}finally{
			try {
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Name: "+prop.getProperty("Name"));
		System.out.println("Age: "+prop.getProperty("Age"));
		System.out.println("Gender: "+prop.getProperty("Gender"));
		System.out.println("Salary: "+prop.getProperty("Salary"));
		System.out.println("Designation: "+prop.getProperty("Designation"));
		
		
	}
	

}
