package Lab7;

import java.util.Arrays;

public class Lab7_1 {
	public static void main(String[] args) {
		String[]products = {"lux", "bottle", "phone", "eyerings", "mouse", "computer", "keyboard", "clothes"};
	    sortStrings(products);
	}
	public static void sortStrings(String[] products){
		System.out.println("Products Before Sorting: ");
		for(String s:products){
			System.out.println(s);
		}
		System.out.println("---------------------");
		Arrays.sort(products);
		System.out.println("Products After Sorting: ");
		for(String s:products){
			System.out.println(s);
		}
		
	}

}
