package Lab7;

import java.util.ArrayList;
import java.util.Collections;

public class Lab7_2 {
	public static void main(String[] args) {
		ArrayList<String> products = new ArrayList<String>();
	    products.add("lux");
	    products.add("bottle");
	    products.add("phone");
	    products.add("mouse");
	    products.add("computer");
	    products.add("watch");
	    sortStrings(products);
	}
	public static void sortStrings(ArrayList<String> products){
		System.out.println("Products Before Sorting: ");
		for(String s:products){
			System.out.println(s);
		}
		System.out.println("---------------------");
		Collections.sort(products);
		System.out.println("Products After Sorting: ");
		for(String s:products){
			System.out.println(s);
		}
		
	}

}
