package Lab8;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Array;




public class Lab8_1 {
		FileInputStream fromFile;
		FileOutputStream toFile;

		public void init(String arg1, String arg2) {
			//Assign the files
			try {
				fromFile = new FileInputStream(arg1);
				toFile = new FileOutputStream(arg2);
			} catch (FileNotFoundException fnfe) {
				System.out.println("Exception: " + fnfe);
				return;
			}  catch (ArrayIndexOutOfBoundsException aioe) {
				System.out.println("Exception: " + aioe);
				return;
			}

		}

		public void copyContents() {
			try {
				byte arr[] = new byte[fromFile.available()];
				fromFile.read(arr);
				int i=0;
				int j=arr.length-1;
				byte temp;
				while(j>i){
					temp = arr[j];
					arr[j] = arr[i];
					arr[i] = temp;
					j--;
					i++;
				}
				toFile.write(arr);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			/*try {
				byte[] arr = new byte[fromFile.available()];
				fromFile.read(arr);
				//byte []rarr= new byte[arr.length];
				for(int i=arr.length-1,j=0;i>=0;i--,j++){
					System.out.print(arr[i]);
					toFile.write(arr[i]);
				
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			/*try{
				byte[] arr = new byte[fromFile.available()];
				fromFile.read(arr);
				int n = arr.length;
				byte[] a = new byte[n];
				for(int i=0;i<n;i++){
					a[n-1-i]=arr[i];
				}
				toFile.write(a);;
			}catch(IOException e){
				System.out.println(e);
			}
			*/

			/*// copy bytes
			try {
				int i = fromFile.read();
				while (i != -1) { //check the end of file
					toFile.write(i);
					i = fromFile.read();
				}
			} catch (IOException ioe) {
				System.out.println("Exception: " + ioe);
				return;
			}*/
		}

		public void closeFiles(){
			//close the files
			try {
				fromFile.close();
				toFile.close();

			} catch (IOException ioe) {
				System.out.println("Exception: " + ioe);
				return;
			}
		}

		public static void main(String[] args) {

			Lab8_1 l1 = new Lab8_1();
			l1.init("d:\\wordcount.txt", "d:\\copyfile.txt");
			l1.copyContents();
			l1.closeFiles();
		}
	

	}


