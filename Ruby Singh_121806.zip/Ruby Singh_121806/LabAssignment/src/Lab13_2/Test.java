package Lab13_2;

public class Test {
	public static void main(String[] args) {
		Timer timer=new Timer();
		Thread thread=new Thread(timer);
		thread.start();
	}

}
