package lab2;

public class Lab2_4main {
	public static void main(String[] args) {
		long phno = Long.parseLong(args[0]);
		Lab2_4 person = new Lab2_4("Divya","Bharti",'F',phno);
		System.out.println("Person Details: ");
		System.out.println("________________");
		System.out.println();
		System.out.println("First Name: "+person.getFirstName());
		System.out.println("Last Name: "+person.getLastName());
		System.out.println("Gender: "+person.getGender());
		System.out.println("Phone number: "+person.getPhoneno());
	}


}
