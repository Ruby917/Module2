package lab2;

public class Lab2_5 {
	String firstName;
	String lastName;
	Gender gender;
	public Lab2_5() {
		super();
	}
	String phoneno;
	public Lab2_5(String firstName, String lastName, Gender gender, String phoneno) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.phoneno = phoneno;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String pno) {
		this.phoneno = pno;
	}
	public void show() {
		System.out.println("First Name:"+firstName);
		System.out.println("Last Name:"+lastName);
		System.out.println("Gender:"+gender);
		System.out.println("Phone No.:"+phoneno);
	}

}
