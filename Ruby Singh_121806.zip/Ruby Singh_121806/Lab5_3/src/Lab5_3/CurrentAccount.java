package Lab5_3;

public class CurrentAccount extends Accounts {
	private int overDraft=10000;

	public CurrentAccount(double balance) {
		super(balance);
	}

	@Override
	public void withdraw(double amt) {
		if((amt-balance)<overDraft){
			balance-=amt;
			
		}
		else{
			System.out.println("Over Draft limit exceeded");
		}
		
	}
}
