package Lab5_3;

public class SavingAccount extends Accounts {
	final public int minimmumBalance=500;

	public SavingAccount(double balance){
		
		super(balance);
	}
	
	@Override
	public void withdraw(double amt) {
		
		if((balance-amt)>=minimmumBalance){
		balance-=amt;
		
	}
	else{
		System.out.println("Balance should be minimum of Rs.500");
	}
	}
}

