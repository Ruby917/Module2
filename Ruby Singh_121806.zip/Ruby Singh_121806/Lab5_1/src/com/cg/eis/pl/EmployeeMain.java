package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.ShowSchemeClass;

public class EmployeeMain {
	public static void main(String[] args) {
		ShowSchemeClass sc = new ShowSchemeClass();
		sc.inputDetails();
		sc.showScheme();
		sc.displayDetails();
		
	}
	
	
	

}
