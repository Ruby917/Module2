package com.cg.mobilepurchasesystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.cg.mobilepurchasesystem.Exception.MobileException;
import com.cg.mobilepurchasesystem.JdbcUtil.JdbcUtil;
import com.cg.mobilepurchasesystem.dto.MobileDetails;
import com.cg.mobilepurchasesystem.dto.PurchaseDetails;

public class IMobileDaoImpl implements IMobileDao {
	Connection conn;
	PreparedStatement ps = null;

	@Override
	public List<MobileDetails> ShowMobileData() throws MobileException {

		List<MobileDetails> mobilelist = new ArrayList<MobileDetails>();
		conn = JdbcUtil.getConnection();
		String query = "SELECT * from mobiles";
		try {
			ps = conn.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				MobileDetails mdetails = new MobileDetails();
				mdetails.setMobileid(rs.getInt("mobileid"));
				mdetails.setMobilename(rs.getString("name"));
				mdetails.setPrice(rs.getDouble("price"));
				mdetails.setQuantity(rs.getDouble("quantity"));
				mobilelist.add(mdetails);
			}

		} catch (SQLException e) {
			System.out.println(e);
			
			throw new MobileException("Data Not Found");
		} finally {

			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println(e);
				
			}

		}

		return mobilelist;
	}

	@Override
	public boolean RemoveMobileDetails(int mobileid) throws MobileException {
		conn = JdbcUtil.getConnection();
		int rec = 0;
		String query = "DELETE FROM mobiles where mobileid=?";
		try {
			ps = conn.prepareStatement(query);
			ps.setInt(1, mobileid);
			rec = ps.executeUpdate();
			if (rec > 0)
				return true;
			

		} catch (SQLException e) {
			System.out.println(e);
			
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println(e);
				throw new MobileException("Data Not Removed");
			}

		}

		return false;
	}

	@Override
	public List<MobileDetails> SearchByPrice(double minprice, double maxprice)
			throws MobileException {
		conn = JdbcUtil.getConnection();
		String query = "SELECT * FROM mobiles where price>=? AND price<=?";
		List<MobileDetails> mobilelist = new ArrayList<MobileDetails>();
		try {
			ps = conn.prepareStatement(query);
			ps.setDouble(1, minprice);
			ps.setDouble(2, maxprice);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				MobileDetails mdetails = new MobileDetails();
				mdetails.setMobileid(rs.getInt("mobileid"));
				mdetails.setMobilename(rs.getString("name"));
				mdetails.setPrice(rs.getDouble("price"));
				mdetails.setQuantity(rs.getDouble("quantity"));
				mobilelist.add(mdetails);
			}
if(mobilelist.isEmpty())
{
	System.out.println("Mobiles for this Range is out of Stock");
}
		} catch (SQLException e) {
			System.out.println(e);
			throw new MobileException("Data Not Found");
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				System.out.println(e);
			}

		}

		return mobilelist;
	}


	@Override
	public boolean UpdateQty(int mobileid, double qty) throws MobileException {
		conn = JdbcUtil.getConnection();
		String query1="select quantity from mobiles where mobileid=?";
		int rec=0;
		int quantity1=0;
		try {
			ps=conn.prepareStatement(query1);
			ps.setInt(1,mobileid);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				quantity1=rs.getInt("quantity");
				
			}
		}
		catch (SQLException e) {
			System.out.println(e);
			throw new MobileException("Not getting Quantity");
		}
			
			if(quantity1>qty)
			{
				String query = "UPDATE mobiles SET quantity =quantity-? where mobileid=? ";
				try {
					ps = conn.prepareStatement(query);
					ps.setDouble(1, qty);
					ps.setInt(2, mobileid);
				rec = ps.executeUpdate();
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally {
					try {
						ps.close();
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						//e.printStackTrace();
					}

				}
				
			}
			else
			{
				System.out.println("Quantity is out of range");
			}
			if(rec>0)
			{
				return true;
			}
			
		return false;
	}
	@Override
	public int addPurchaseDetails(PurchaseDetails purchase)
			throws MobileException {
		
		int pId=0;
		
		String query="INSERT INTO purchasedetails VALUES(?,?,?,?,?,?)";
		try {
			pId=getPurchaseId();
			
			conn=JdbcUtil.getConnection();
			ps=conn.prepareStatement(query);
			ps.setInt(1,pId);
			ps.setString(2,purchase.getCname());
			ps.setString(3,purchase.getMailid());
			ps.setString(4,purchase.getPhoneno());
			
			Calendar calendar = Calendar.getInstance();
		    java.sql.Date currentDate = new java.sql.Date(calendar.getTime().getTime());
	    	 ps.setDate(5, currentDate);
			
			ps.setInt(6, purchase.getMobileid());
			int status=ps.executeUpdate();
			if(status==1)
			System.out.println("Data Inserted Successfully");
		}
			catch (SQLException e) {
				System.out.println(e);
				throw new MobileException("Data Not Inserted..");
			}
		finally
		{
			
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return pId;
	}

	private int getPurchaseId() throws MobileException {
		int id=0;
		String query="SELECT purchase_seq.NEXTVAL FROM DUAL";
		Connection conn=null;
		PreparedStatement ps=null;
		
		try {
			conn=JdbcUtil.getConnection();
			ps=conn.prepareStatement(query);
			ResultSet res=ps.executeQuery();
			while(res.next()){
			id=res.getInt(1);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return id;

	
	}
	
	@Override
	public List<PurchaseDetails> showPurchaseDetails() throws MobileException {
		List<PurchaseDetails> purchaselist=new ArrayList<PurchaseDetails>();
		conn=JdbcUtil.getConnection();
		String query="SELECT * from purchasedetails";
		try {
			ps=conn.prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				PurchaseDetails pdetails=new PurchaseDetails();
			
				pdetails.setPurchaseid(rs.getInt("purchaseid"));
				pdetails.setCname(rs.getString("cname"));
				pdetails.setMailid(rs.getString("mailid"));
				pdetails.setPhoneno(rs.getString("phoneno"));
				pdetails.setPurchasedate(rs.getDate("purchasedate"));
				pdetails.setMobileid(rs.getInt("mobileid"));
				purchaselist.add(pdetails);
			}
			if(purchaselist.isEmpty())
			{
				System.out.println("No Records");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("Data Not Found");
		}
		finally
		{
			
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return purchaselist;
	}
@Override
	public int checkMobileid(int mid)
	{
		
		String query="SELECT mobileid from mobiles";
		
		try {
			conn=JdbcUtil.getConnection();
			ps=conn.prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				//MobileDetails mobile=new MobileDetails();
				if( mid==rs.getInt("mobileid"))
				{
					return 1;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return 0;
	}


}
