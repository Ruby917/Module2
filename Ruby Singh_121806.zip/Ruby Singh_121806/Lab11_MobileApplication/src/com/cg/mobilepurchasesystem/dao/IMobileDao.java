package com.cg.mobilepurchasesystem.dao;

import java.util.List;

import com.cg.mobilepurchasesystem.Exception.MobileException;
import com.cg.mobilepurchasesystem.dto.MobileDetails;
import com.cg.mobilepurchasesystem.dto.PurchaseDetails;

public interface IMobileDao {
List<MobileDetails> ShowMobileData() throws MobileException ; 
boolean RemoveMobileDetails(int mobileid) throws MobileException;
List<MobileDetails> SearchByPrice(double minprice,double maxprice) throws MobileException; 
boolean UpdateQty(int mobileid,double qty) throws MobileException;
public int addPurchaseDetails(PurchaseDetails purchase) throws MobileException;
public List<PurchaseDetails> showPurchaseDetails() throws MobileException;
public int checkMobileid(int mid) throws MobileException;
}
