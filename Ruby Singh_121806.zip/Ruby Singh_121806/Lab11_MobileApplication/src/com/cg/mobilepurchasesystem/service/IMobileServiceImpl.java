package com.cg.mobilepurchasesystem.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.mobilepurchasesystem.Exception.MobileException;
import com.cg.mobilepurchasesystem.dao.IMobileDao;
import com.cg.mobilepurchasesystem.dao.IMobileDaoImpl;
import com.cg.mobilepurchasesystem.dto.MobileDetails;
import com.cg.mobilepurchasesystem.dto.PurchaseDetails;

public class IMobileServiceImpl implements IMobileService {
	IMobileDao mobiledao=new IMobileDaoImpl();
	@Override
	public List<MobileDetails> ShowAll() throws MobileException {
		return mobiledao.ShowMobileData();
		
	} 
	@Override		
	public boolean DeleteMobileDetails(int mobileid) throws MobileException
	{
		return mobiledao.RemoveMobileDetails(mobileid);
	
		
	}
	@Override
	public List<MobileDetails> SearchPrice(double minprice,double maxprice) throws MobileException
	{
		return mobiledao.SearchByPrice(minprice, maxprice);
		
	}
	@Override
	public boolean UpdateQtyService(int mobileid, double qty)
			throws MobileException {
		return mobiledao.UpdateQty(mobileid, qty);
	}
	@Override
	public int addPurchaseDetail(PurchaseDetails purchase) throws MobileException
	{
		return mobiledao.addPurchaseDetails(purchase);
		
		
	}
	
	
	public List<PurchaseDetails> showPurchaseDetail() throws MobileException
	{
		return mobiledao.showPurchaseDetails();
		
	}
	public static void validateName(String patt,String name) throws MobileException{
	boolean value=Pattern.matches(patt,name);
	if(!value){
		throw new MobileException("Name should be of minimum 4 and maximum 10 and First letter must be capital");
	}
		
	}
	public static void validatePhoneno(String patt,String name) throws MobileException{
		boolean value=Pattern.matches(patt,name);
		if(!value){
			throw new MobileException("PhoneNo must be of 10 digits and should start with 7 or 8 or 9");
		}
			
		}
	public static void validateMailid(String patt,String name) throws MobileException{
		boolean value=Pattern.matches(patt,name);
		if(!value){
			throw new MobileException("Please Enter Valid Email id");
		}
			
		}
	public static void validateMobilId(String patt,String name) throws MobileException{
		boolean value=Pattern.matches(patt,name);
		if(!value){
			throw new MobileException("MobileId should be of 4 digits  and should start with 1");
		}
			
		}


	@Override
	public int checkServiceMobileid(int mid) throws MobileException {
		return mobiledao.checkMobileid(mid);
	}
}
