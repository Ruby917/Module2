package com.cg.mobilepurchasesystem.service;

import java.util.List;

import com.cg.mobilepurchasesystem.Exception.MobileException;
import com.cg.mobilepurchasesystem.dto.MobileDetails;
import com.cg.mobilepurchasesystem.dto.PurchaseDetails;

public interface IMobileService {
	List<MobileDetails> ShowAll() throws MobileException ; 
	boolean DeleteMobileDetails(int mobileid) throws MobileException;
	List<MobileDetails> SearchPrice(double minprice,double maxprice) throws MobileException;
	boolean UpdateQtyService(int mobileid,double qty) throws MobileException;
	public int addPurchaseDetail(PurchaseDetails purchase) throws MobileException;
	public List<PurchaseDetails> showPurchaseDetail() throws MobileException;
	public int checkServiceMobileid(int mid) throws MobileException;
}
