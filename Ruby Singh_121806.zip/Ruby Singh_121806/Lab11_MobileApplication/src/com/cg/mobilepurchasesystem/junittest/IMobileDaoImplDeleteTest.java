package com.cg.mobilepurchasesystem.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobilepurchasesystem.Exception.MobileException;
import com.cg.mobilepurchasesystem.dao.IMobileDaoImpl;

public class IMobileDaoImplDeleteTest {
	IMobileDaoImpl mobiledao=null;
	@Before
	public void setup()
	{
		mobiledao=new IMobileDaoImpl();
	}
	@Test
	public void testRemoveMobileDetails() {
		try {
			assertTrue(mobiledao.RemoveMobileDetails(1003));
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@After
	public void tearDown()
	{
		mobiledao=null;
	}
}
