package com.cg.mobilepurchasesystem.junittest;

import static org.junit.Assert.*;

import java.sql.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobilepurchasesystem.Exception.MobileException;
import com.cg.mobilepurchasesystem.dao.IMobileDao;
import com.cg.mobilepurchasesystem.dao.IMobileDaoImpl;
import com.cg.mobilepurchasesystem.dto.PurchaseDetails;

public class IPurchaseDaoImplAddtest {
	IMobileDao purchase=null;
	PurchaseDetails purchasede=null;
	@Before
	public void beforeTest(){
		purchase=new IMobileDaoImpl();
		purchasede=new PurchaseDetails();
	//	purchasede.setPurchaseid(100);
		purchasede.setCname("Vandana11");
		purchasede.setMailid("van@gamil.com");
		purchasede.setPhoneno("8286383611");
	    java.util.Date d1= new java.util.Date();
	    
		Date sysdate=new Date(d1.getTime());
		purchasede.setPurchasedate(sysdate);
		purchasede.setMobileid(1003);
		
		
		
	}
	@Test
	public void testAddPurchaseDetails() throws MobileException {
		
			assertEquals(114,purchase.addPurchaseDetails(purchasede));
	
		
	}
	@After
	public void tearDown()
	{
		purchase=null;
		purchasede=null;
	}
}
