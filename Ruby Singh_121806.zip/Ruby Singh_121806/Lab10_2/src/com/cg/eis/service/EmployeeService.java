package com.cg.eis.service;

import java.util.List;

import com.cg.eis.bean.Employee;

public interface EmployeeService {
	public void addEmployee();
	public void showScheme(Employee e);
    public List<Employee> displayDetails();
    public boolean deleteEmployee();
}
