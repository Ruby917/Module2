package Lab9_1;
import org.junit.*;

import static org.junit.Assert.*;
public class PersonTest
{
@Test
public void testGetFullName()
{
System.out.println("from TestPerson2");
Person per = new Person("Robert","King");
assertEquals("Robert King",per.getFullName());
}
@Test (expected=IllegalArgumentException.class)
public void testNullsInName()
{
System.out.println("from TestPerson2 testing exceptions");
Person per1 = new Person(null,null);
}
}