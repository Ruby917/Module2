package Lab9_2;

import org.junit.Assert;
import org.junit.Test;

public class ExceptionTest {
Exception eCheck =new Exception("Invalid Name");
	@Test
	public void testException() {
		Assert.assertNotNull(eCheck);
		
	}

}
