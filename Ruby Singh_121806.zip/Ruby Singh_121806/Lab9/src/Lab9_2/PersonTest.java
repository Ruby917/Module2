package Lab9_2;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PersonTest {
	Person p;
@Before
public void setUp()
{
	 p=new Person("vandana","Nagpal",'F');
}
	@Test
	public void testGetFirstname() {
	assertEquals("vandana", p.getFirstname());
	}

	@Test
	public void testGetLastname() {
		assertEquals("Nagpal", p.getLastname());
	}

	@Test
	public void testGetGender() {
		assertEquals('F', p.getGender());
	}

}