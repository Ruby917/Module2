package Lab9_2;

public class Exceptions extends Exception {

	public Exceptions(String msg) {
		super(msg);
	}

}
