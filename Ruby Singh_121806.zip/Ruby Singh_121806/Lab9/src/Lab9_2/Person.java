package Lab9_2;

public class Person {

	
	String firstname;
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	String lastname;
	char gender;
	public Person(String firstname,String lastname,char gender)
	{
		super();
		this.firstname=firstname;
		this.lastname=lastname;
		this.gender=gender;
	
}
	public Person()
	{
		super();
	}
	

}
