package Lab9_2;

public class PersonMain {

	public static void main(String[] args) {
	displayDetails();

	}
public static  void displayDetails()
{
	Person p=new Person("Ruby","Singh",'F');
	
	System.out.println("First Name : " +p.getFirstname());
	System.out.println("Last Name :" +p.getLastname());
	System.out.println("Gender:" +p.getGender());
}
}
