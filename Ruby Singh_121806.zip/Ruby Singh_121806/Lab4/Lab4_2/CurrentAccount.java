package Lab4.Lab4_2;

public class CurrentAccount extends Accounts {

	private int overDraft=10000;
	
	
	public CurrentAccount(double balance) {
		super(balance);
	}


	public void withdraw(double amt){
		double bal=getBalance();
		if((amt-bal)<overDraft){
			super.withdraw(amt);
			
		}
		else{
			System.out.println("overDraft limit exceeded");
		}
	}
}
