package Lab4.Lab4_1;

public class person {
	private String name;
	private float age;
	@Override
	public String toString() {
		return "person [name=" + name + ", age=" + age + "]";
	}
	public String getName() {
		return name;
	}
	public person() {
		super();
	}
	public person(String name, float age) {
		super();
		this.name = name;
		this.age = age;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}

}
