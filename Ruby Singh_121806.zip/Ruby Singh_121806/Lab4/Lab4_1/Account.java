package Lab4.Lab4_1;

public class Account {
	private long accNum;
	private double balance;
	private person accHolder;
	long count=476457865;
	public void deposite(double amt){
		balance = balance + amt;
	}
	public void withdraw(double amt){
		if(balance-amt>=500){
			balance-=amt;
		}else{
			System.out.println("Insufficient Balance");
		}
	}
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}
	public Account() {
		super();
		count++;
		accNum=count;
	}
	public Account(double balance) {
		super();
		count++;
		this.accNum = count;
		this.balance = balance;
	}
	public long getAccNum() {
		return accNum;
	}
	public double getBalance() {
		return balance;
	}
	public person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(person accHolder) {
		this.accHolder = accHolder;
	}

}
