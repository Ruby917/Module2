package Lab4.Lab4_1;

public class TestAccount {
	public static void main(String[] args) {
		person smith = new person("Smith",45);
		person kathy = new person("Kathy",35);
		Account smithacc = new Account(2000);
		smithacc.setAccHolder(smith);
		System.out.println(smithacc);
		Account kathyacc = new Account(3000);
		kathyacc.setAccHolder(kathy);
		System.out.println(kathyacc);
		/*System.out.println("Smith Details before transaction:");
		System.out.println("Account number:"+smithacc.getAccNum());
		System.out.println("balance:"+smithacc.getBalance());
		System.out.println("Kathy Details before transaction:");
		System.out.println("Account number:"+kathyacc.getAccNum());
		System.out.println("balance:"+kathyacc.getBalance());
	    System.out.println("______________________________________");
		System.out.println("Smith Details after transaction:");
		System.out.println("Account number:"+smithacc.getAccNum());
		System.out.println("balance:"+smithacc.getBalance());
		System.out.println("Kathy Details after transaction:");
		System.out.println("Account number:"+kathyacc.getAccNum());
		System.out.println("balance:"+kathyacc.getBalance());*/
		smithacc.deposite(2000);
		kathyacc.withdraw(2000);
		System.out.println("Update balance of smith: "+smithacc.getBalance());
		System.out.println("Update balance of kathy: "+kathyacc.getBalance());

	}

}
