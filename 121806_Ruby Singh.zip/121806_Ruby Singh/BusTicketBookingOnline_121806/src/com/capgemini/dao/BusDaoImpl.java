package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;
import com.capgemini.util.DbUtil;

public class BusDaoImpl implements BusDao {
	private static final Logger mylogger= Logger.getLogger(BusDaoImpl.class);

	Connection conn;
	PreparedStatement pstmt;
	@Override
	public ArrayList<BusBean> retrieveBusDetails() {
		ArrayList<BusBean> mList = new ArrayList<BusBean>();
		conn=DbUtil.getConnection();
		String query = "SELECT * FROM BUSDETAILS";
		try {
			pstmt = conn.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				BusBean busBean = new BusBean();
				busBean.setBusId(rs.getInt(1));
				busBean.setBusType(rs.getString(2));
				busBean.setFromStop(rs.getString(3));
				busBean.setToStop(rs.getString(4));
				busBean.setFare(rs.getInt(5));
				busBean.setAvailableSeats(rs.getInt(6));
				busBean.setDateOfJourney(rs.getDate(7));
				mList.add(busBean);
			}
			mylogger.info("Data Displayed Successfully");
		} catch (SQLException e) {
			mylogger.error("data not found");
			e.printStackTrace();
		}
		
		return mList;
	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException {
		int busid = bookingBean.getBusId() ;
		int checkBusId = chechBusid(busid);
		int bookedSeats = bookingBean.getNoOfSeats();
		int checkAvailSeats = chechAvailableSeat(busid,bookedSeats);
		int bookingId=0;
		if(checkBusId==1){
			if(checkAvailSeats==1){
				int bId=0;
				String query="INSERT INTO BOOKINGDETAILS VALUES(?,?,?,?)";
				
				bId=getBookingid();
				conn=DbUtil.getConnection();
				try {
					pstmt=conn.prepareStatement(query);
					pstmt.setInt(1,bId);
					pstmt.setString(2, bookingBean.getCustId());
			        pstmt.setInt(3, bookingBean.getBusId());
			        pstmt.setInt(4, bookingBean.getNoOfSeats());
					int status=pstmt.executeUpdate();
					if(status==1){
						updateAvailableNoOfSeats(busid,bookedSeats);
						System.out.println("Thank you. Your booking Id is "+bId);
						mylogger.info("Seat Booked successfully");
						bookingId = bId;
					}
					
				} catch (SQLException e) {
					mylogger.error("Seat has been booked successfully");
					e.printStackTrace();
				}
				finally{
					try {
						pstmt.close();
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
					
				}
				
			}
			else{
				System.out.println("Sorry no seats are available");
			}
		
		}else{
			System.out.println("Bus Id does not exist");
		}
		
		return bookingId;
	}
	
	public int chechBusid(int bus_id){
		String query = "SELECT BUSID FROM BUSDETAILS";
		conn=DbUtil.getConnection();
		try {
			pstmt = conn.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				if(bus_id==rs.getInt("busid")){
					mylogger.info("Bus id has been checked succefully");
					return 1;
				}
			}
		} catch (SQLException e) {
			mylogger.error("Bus id has not been checked succefully");
			e.printStackTrace();
		}
		return 0;
	}
	public int chechAvailableSeat(int bus_id,int bookedSeats){
		String query = "SELECT BUSID,AVAILABLESEATS FROM BUSDETAILS";
		conn=DbUtil.getConnection();
		try {
			pstmt = conn.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				if(bus_id==rs.getInt("busid")&& (bookedSeats>0 && bookedSeats<=rs.getInt("availableseats"))){
					mylogger.info("Available seats has been checked successfully");
					return 1;
				}
			}
		} catch (SQLException e) {
			mylogger.error("Available seats has not been checked successfully");
			e.printStackTrace();
		}
		return 0;
	}
    public void updateAvailableNoOfSeats(int busid,int bookedSeats){
    	String query = "UPDATE BUSDETAILS SET AVAILABLESEATS=AVAILABLESEATS-? WHERE BUSID=?";
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1,busid);
			pstmt.setInt(2, bookedSeats);
			pstmt.executeUpdate();
			mylogger.info("Available seats has been updated successfully");
		} catch (SQLException e) {
			e.printStackTrace();
			mylogger.error("Available seats has not been updated");
			try {
				throw new BookingException("data not found!!");
			} catch (BookingException e1) {
				e1.printStackTrace();
			}
		}finally{
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
    	
    }
	public int getBookingid() throws BookingException {
		int id= 0;
		String query="SELECT Booking_Id_Seq .NEXTVAL FROM DUAL";
		Connection conn=null;
		ResultSet res=null;
		conn=DbUtil.getConnection();
		try {
			pstmt=conn.prepareStatement(query);
			res=pstmt.executeQuery();
			while(res.next()){
			id=res.getInt(1);
			}
			mylogger.info("Booking Id has beeb generated");
		} catch (SQLException e) {
			mylogger.error("Booking Id has not been generated");
			e.printStackTrace();
		
		}finally{
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return id;
	}

}
