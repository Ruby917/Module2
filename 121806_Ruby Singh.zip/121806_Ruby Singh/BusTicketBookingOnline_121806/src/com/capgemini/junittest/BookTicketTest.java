package com.capgemini.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.bean.BookingBean;
import com.capgemini.client.MainClient;
import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.exception.BookingException;

public class BookTicketTest {
	BusDao busDao = null;
	BookingBean bookingBean = null;
	@Before
	public void setUp() throws Exception {
		busDao = new BusDaoImpl();
		bookingBean = new BookingBean();
		bookingBean.setCustId("A111111");
		bookingBean.setBusId(3);
		bookingBean.setNoOfSeats(2);
	}

	@After
	public void tearDown() throws Exception {
		busDao = null;
		bookingBean = null;
	}

	@Test
	public void test() {
		try {
			assertEquals(1008,busDao.bookTicket(bookingBean));
		} catch (BookingException e) {
			e.printStackTrace();
		}
	}

}
