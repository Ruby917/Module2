package com.capgemini.lesson3.control;

public class IfExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 0;

	    if (a == 1) {
	      System.out.println("one");
	    } else if (a == 2) {
	      System.out.println("two");
	    } else if (a == 3) {
	      System.out.println("three");
	    } else {
	      System.out.println("invalid");
	    }

	}

}
