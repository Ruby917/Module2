package com.capgemini.lesson3.operators;

public class LeftShift {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  int i;
		    int num = 16;
		   
		    for(i=0; i<4; i++) {
		      num = num << 1;
		      System.out.println(num);
		    
		    }
	}
}
