package com.capgemini.lesson18.mock;

public interface LoginService {
boolean login(String username, String password);
}
