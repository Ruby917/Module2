package com.cg.eis.pl;

import java.util.List;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeServiceImpl;


public class EmployeeMain {
	public static void main(String[] args) {
		EmployeeServiceImpl empService = new EmployeeServiceImpl();
		int choice;
		do{
			System.out.println("---Employee------");
			System.out.println("1.Add Employee");
			System.out.println("2.Display Details of Employee");
			System.out.println("3.Delete Employee Data");
			System.out.println("4.Exit");
			System.out.println("-----------------");
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the choice: ");
			choice = sc.nextInt();
			switch(choice){
			case 1:		
				empService.addEmployee();
				break;
			case 2:
				List<Employee> e = null;
				e =empService.displayDetails();
				for (Employee emp : e) {
					System.out.println("Employee Id is "+emp.getId());
					System.out.println("Employee Name is "+emp.getName());
					System.out.println("Salary of Employee  is "+emp.getSalary());
					System.out.println("Designation of Employee is "+emp.getDesignation());
					System.out.println("Insurance Scheme is: "+emp.getInsuranceScheme());
					System.out.println("-----------------------------");
				}
				break;
			case 3:
				empService.deleteEmployee();
				break;
			case 4:System.out.println("Exited");
				break;
			}
			
		}while(choice!=4);
		
	}
}
