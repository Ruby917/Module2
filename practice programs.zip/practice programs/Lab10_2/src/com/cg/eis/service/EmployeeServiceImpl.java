	package com.cg.eis.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import com.cg.eis.bean.Employee;



public class EmployeeServiceImpl implements EmployeeService {
	Connection conn;
	PreparedStatement pstmt;
	HashMap<Integer,Employee> list = new HashMap<Integer,Employee>();
	@Override
	public void addEmployee() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of employees: ");
		int n = sc.nextInt();
		for(int i=1;i<=n;i++){
			System.out.println("Enter the Id of employee "+i+" : ");
			int id = sc.nextInt();
			System.out.println("Enter the Name of employee "+i+" : ");
			String name = sc.next();
			System.out.println("Enter the Salary of employee "+i+" : ");
			double salary = sc.nextDouble();
			System.out.println("Enter the Designation of employee "+i+" : ");
			String designation = sc.next();
			Employee e = new Employee(id,name,salary,designation);
			showScheme(e);
			String query="INSERT INTO EMPLOYEES VALUES(?,?,?,?,?)";
			try {

				conn=getConnection();
				pstmt=conn.prepareStatement(query);
				pstmt.setInt(1,e.getId());
				pstmt.setString(2, e.getName());
				pstmt.setDouble(3, e.getSalary());
				pstmt.setString(4, e.getDesignation());
				pstmt.setString(5, e.getInsuranceScheme());
				pstmt.executeUpdate();
				System.out.println("data inserted successfully");
			} catch (SQLException en) {
				System.out.println("data not inserted successfully");
				System.out.println(en);
			}finally{
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException er) {
					er.printStackTrace();
				}
			}		
		}
	}
	

	@Override
	public List<Employee> displayDetails() {
		conn=getConnection();
		ResultSet rs=null;
		String query = "SELECT * FROM EMPLOYEES";
		List<Employee> eList = new ArrayList<Employee>();
		try {
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			while(rs.next()){
				Employee e = new Employee();
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setSalary(rs.getDouble(3));
				e.setDesignation(rs.getString(4));
				e.setInsuranceScheme(rs.getString(5));
				eList.add(e);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return eList;
	}
	
	public boolean deleteEmployee(){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the employee Id you want to delete: ");
		int empid = sc.nextInt();
		conn=getConnection();
		String query = "DELETE FROM EMPLOYEES WHERE EMPID=?";
		int rec=0;
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1,empid);
			rec = pstmt.executeUpdate();
			if(rec>0){
				System.out.println("Employee data deleted successfully");
				return true;
			}
			System.out.println("Employee data deleted successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	
	@Override
	public void showScheme(Employee e) {
		if((e.salary>5000 && e.salary<20000) && e.designation.equals("System Associate")){
			e.insuranceScheme = "Scheme C";
		}
		else if((e.salary>=20000 && e.salary<40000) && e.designation.equals("Programmer")){
			e.insuranceScheme = "Scheme B";		
			}
		else if(e.salary>=40000 && e.designation.equals("Manager")){
			e.insuranceScheme = "Scheme A";			
			}
		else if(e.salary<5000 && e.designation.equals("Clerk")){
			e.insuranceScheme = "No Scheme";			
			}
		else{
			System.out.println("Invalid Input");
		}
		
		
	}
	
	public static Properties loadProperty(){
		Properties prop = new Properties();
		InputStream in = null;
		try {
			in = new FileInputStream("oracle.properties");
			try {
				prop.load(in);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}finally{
			try {
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return prop;
	}
	
	
	
	public static Connection getConnection(){
		Connection conn=null;
		Properties prop = loadProperty();
		String url = prop.getProperty("url");
		String driver = prop.getProperty("driver");
		String username = prop.getProperty("username");
		String password = prop.getProperty("password");
		try {
			Class.forName(driver);
			try {
				conn = DriverManager.getConnection(url,username,password);
			} catch (SQLException e){
			e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return conn;
		
	}

	
}
