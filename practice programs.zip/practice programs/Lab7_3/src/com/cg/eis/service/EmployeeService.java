package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface EmployeeService {
	public void addEmployee();
	public void showScheme(Employee e);
    public void displayDetails();
}
