package com.cg.mobilepurchasesystem.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobilepurchasesystem.Exception.MobileException;
import com.cg.mobilepurchasesystem.dao.IMobileDao;
import com.cg.mobilepurchasesystem.dao.IMobileDaoImpl;



public class IPurchaseShowTest {
	IMobileDao purchase = null;

	@Before
	public void setup()
	{
		purchase = new IMobileDaoImpl();
	}
	@Test
	public void testShowMobileData() {
		
		try {
			assertNotNull(purchase.showPurchaseDetails());
		} catch (MobileException e) {
			e.printStackTrace();
		}
	}



	@After
	public void tearDown()
	{
		purchase = null;
	}
}
