package com.cg.mobilepurchasesystem.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobilepurchasesystem.Exception.MobileException;
import com.cg.mobilepurchasesystem.dao.IMobileDao;
import com.cg.mobilepurchasesystem.dao.IMobileDaoImpl;

public class IPurchaseMobilidTest {
	IMobileDao purchase = null;

	@Before
	public void setup()
	{
		purchase = new IMobileDaoImpl();
	}
	@Test
	public void testCheckMobileid() {
		try {
			assertEquals(1,purchase.checkMobileid(1003));
		} catch (MobileException e) {
			e.printStackTrace();
		}
	}
	@After
	public void tearDown()
	{
		purchase = null;
	}
}
