package com.cg.mobilepurchasesystem.dto;

import java.sql.Date;





public class PurchaseDetails {
private int purchaseid;
private String cname;
private String mailid;
private String phoneno;
private Date purchasedate;
private int mobileid;
public PurchaseDetails(int purchaseid, String cname, String mailid,
		String phoneno, Date purchasedate,int mobileid) {
	super();
	this.purchaseid = purchaseid;
	this.cname = cname;
	this.mailid = mailid;
	this.phoneno = phoneno;
	this.purchasedate = purchasedate;
	this.mobileid=mobileid;
}
public int getMobileid() {
	return mobileid;
}

public void setMobileid(int mobileid) {
	this.mobileid = mobileid;
}
public PurchaseDetails() {
	super();
}
public void setPurchaseid(int purchaseid) {
	this.purchaseid = purchaseid;
}
public void setCname(String cname) {
	this.cname = cname;
}
public void setMailid(String mailid) {
	this.mailid = mailid;
}
public void setPhoneno(String phoneno) {
	this.phoneno = phoneno;
}
public void setPurchasedate(Date purchasedate) {
	this.purchasedate = (purchasedate);
}
public int getPurchaseid() {
	return purchaseid;
}
public String getCname() {
	return cname;
}
public String getMailid() {
	return mailid;
}
public String getPhoneno() {
	return phoneno;
}

public Date getPurchasedate() {
	return purchasedate;
}
@Override
public String toString() {
	return "PurchaseDetails [purchaseid=" + purchaseid + ", cname=" + cname
			+ ", mailid=" + mailid + ", phoneno=" + phoneno + ", purchasedate="
			+ purchasedate + ", mobileid=" + mobileid + "]";
}


}
