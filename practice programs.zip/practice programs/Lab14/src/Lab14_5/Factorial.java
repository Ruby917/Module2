package Lab14_5;

public class Factorial {
	double fact=0.0;
	public double calc(double input){
		if(input<=0){
			return 1.0;
		}
		fact=fact+(input*calc(input-1));
		return fact;
	}

}
