package Lab14_2;

@FunctionalInterface
public interface AppendSpace {
	public String addSpace(String input);

}
