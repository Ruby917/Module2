package Lab6.Lab6_1;

public class BlankNameException extends Exception{
	

	public BlankNameException(String msg) {
		super(msg);
	}
}
