package Lab6.Lab6_1;

import java.util.Scanner;



public class PersonMain {
	public static void main(String[] args) throws BlankNameException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First Name:");
		String fName = sc.nextLine();
		System.out.println("Enter Last Name:");
		String lName = sc.nextLine();
		Person person = new Person(fName,lName,'F');
		System.out.println("Person Details:");
		System.out.println("________________");
		System.out.println();
		System.out.println("First Name:"+person.getFirstName());
		System.out.println("Last Name:"+person.getLastName());
		System.out.println("Gender:"+person.getGender());
	}

}