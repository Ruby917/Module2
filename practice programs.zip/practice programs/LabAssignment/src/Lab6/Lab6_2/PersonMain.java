package Lab6.Lab6_2;

import java.util.Scanner;



public class PersonMain {
	public static void main(String[] args) throws AgeException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First Name: ");
		String fName = sc.next();
		System.out.println("Enter Last Name: ");
		String lName = sc.next();
		System.out.println("Enter Age: ");
		int age = sc.nextInt();
		Person person = new Person(fName,lName,age);
		System.out.println("Person Details:");
		System.out.println("________________");
		System.out.println();
		System.out.println("First Name:"+person.getFirstName());
		System.out.println("Last Name:"+person.getLastName());
		System.out.println("Age:"+person.getAge());
	}

}