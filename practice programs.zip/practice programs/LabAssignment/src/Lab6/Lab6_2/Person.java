package Lab6.Lab6_2;

public class Person {
	String firstName;
	String lastName;
	int age;
	             
	public Person(String firstName, String lastName, int age) throws AgeException{
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		if(age>15){
			this.age = age;
		}else{
			throw new AgeException("Age should be above 15");
		}
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) throws AgeException{
		if(age>15){
			this.age = age;
		}else{
			throw new AgeException("Age should be above 15");
		}
	}

	public Person() {
		super();
	}
	
	

}
