package lab2;

import java.util.Scanner;



public class Lab2_5main {
	
	public static void main(String[] args) {
		Gender gender = null;
		Lab2_5 l1 = new Lab2_5();
		l1.setFirstName("Ruby");
		l1.setLastName("Singh");
		System.out.println("Enter phone number: ");
		Scanner sc = new Scanner(System.in);
		String pno = sc.nextLine();
		l1.setPhoneno(pno);
		System.out.println("Enter Gender:");
		String m_gender = sc.nextLine();
		gender = Gender.valueOf(m_gender);
		l1.setGender(gender);
		l1.show();
	}

}
