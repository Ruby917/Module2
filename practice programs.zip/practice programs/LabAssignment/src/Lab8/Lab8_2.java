package Lab8;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

public class Lab8_2 {
	public static void main(String[] args) {
		FileInputStream fromFile = null;
		try {
			fromFile = new FileInputStream("numbers.txt");
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		
		Scanner s = new Scanner(fromFile).useDelimiter(",");
		System.out.println("Even numbers Are:");
			while(s.hasNext()){
				String n = s.next();
				int num = Integer.parseInt(n);
				if(num%2==0){
					System.out.println(num);
				}
					
				}
			s.close();
		
	}

}
