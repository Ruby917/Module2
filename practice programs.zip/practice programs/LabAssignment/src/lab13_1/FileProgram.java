package lab13_1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class FileProgram  {
	public static void main(String[] args) {
				FileInputStream fromFile;
			FileOutputStream toFile;
			try {
				fromFile = new FileInputStream("source.txt");
				toFile = new FileOutputStream("target.txt");
				
				CopyDataThread cs=new CopyDataThread(fromFile,toFile);
				cs.start();
				
			} catch (FileNotFoundException e) {
				System.out.println("File Not Found !");
				e.printStackTrace();
			}
			
			
	}

}