package com.cg.eis.pl;

import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.ShowSchemeClass;

public class EmployeeMain {
	public static void main(String[] args) throws EmployeeException {
		ShowSchemeClass sc = new ShowSchemeClass();
		sc.inputDetails();
		sc.showScheme();
		sc.displayDetails();
	}
}
