package com.cg.mobilePurchaseSystem.dao;

import java.util.List;

import com.cg.mobilePurchaseSystem.dto.Mobile;
import com.cg.mobilePurchaseSystem.dto.Purchase;
import com.cg.mobilePurchaseSystem.exception.MobileException;

public interface IpurchaseDao {
	boolean addPurchaseDetails(Purchase p) throws MobileException;
	List<Purchase> showPurchaseDetails() throws MobileException;
	public  int getPurchaseid() throws MobileException;
}
