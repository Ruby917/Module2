package com.cg.mobilePurchaseSystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.cg.mobilePurchaseSystem.dto.Purchase;
import com.cg.mobilePurchaseSystem.exception.MobileException;
import com.cg.mobilePurchaseSystem.util.DbUtil;


public class PurchaseDaoImpl implements IpurchaseDao{
	Connection conn;
	PreparedStatement pstmt;
	public boolean addPurchaseDetails(Purchase p) throws MobileException {
		conn=DbUtil.getConnection();
		String query = "INSERT INTO PURCHASEDETAILS VALUES(?,?,?,?,?,?)";
		int p_id=getPurchaseid();
		int rec=0;
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, p_id);
			pstmt.setString(2, p.getCustomer_name());
            pstmt.setString(3, p.getMail_id());
            pstmt.setString(4, p.getPhone_no());
            Calendar cal = Calendar.getInstance();
            java.sql.Date currentDate = new java.sql.Date(cal.getTime().getTime());
            pstmt.setDate(5, currentDate);
            pstmt.setInt(6, p.getMobileid());
            rec = pstmt.executeUpdate(query);
            if(rec>0){
            	return true;
            }
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}

	public List<Purchase> showPurchaseDetails() throws MobileException {
		conn=DbUtil.getConnection();
		ResultSet rs=null;
		String query = "SELECT * FROM PURCHASEDETAILS";
		List<Purchase> pList = new ArrayList<Purchase>();
		try {
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			while(rs.next()){
				int p_id = rs.getInt(1);
				String c_name = rs.getString(2);
				String email = rs.getString(3);
				String p_no = rs.getString(4);
				java.sql.Date p_date = rs.getDate(5);
				int m_id = rs.getInt(6);
				Purchase p = new Purchase();
				p.setPurchaseId(p_id);
				p.setCustomer_name(c_name);
				p.setMail_id(email);
				p.setPhone_no(p_no);
				p.setPurchase_date(p_date);
				p.setMobileid(m_id);
				pList.add(p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return pList;
	}
    int id;
	public  int getPurchaseid(){
		String query="SELECT purchase_seq.NEXTVAL FROM DUAL";
		Connection conn=null;
		ResultSet res=null;
		conn=DbUtil.getConnection();
		try {
			pstmt=conn.prepareStatement(query);
			res=pstmt.executeQuery();
			while(res.next()){
			id=res.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		
		}finally{
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return id;
	}

}
