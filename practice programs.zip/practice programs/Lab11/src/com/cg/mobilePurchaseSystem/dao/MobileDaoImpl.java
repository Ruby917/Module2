package com.cg.mobilePurchaseSystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.mobilePurchaseSystem.dto.Mobile;
import com.cg.mobilePurchaseSystem.exception.MobileException;
import com.cg.mobilePurchaseSystem.util.DbUtil;

public class MobileDaoImpl implements ImobileDao{
	Connection conn;
	PreparedStatement pstmt;
	public List<Mobile> showAllMobile() throws MobileException{
		conn=DbUtil.getConnection();
		String query = "SELECT * FROM MOBILES";
		List<Mobile> mList = new ArrayList<Mobile>();
		try {
			pstmt = conn.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				int m_id = rs.getInt(1);
				String m_name = rs.getString(2);
				double m_price = rs.getInt(3);
				int m_qty = rs.getInt(4);
				Mobile m = new Mobile();
				m.setMobileid(m_id);
				m.setName(m_name);
				m.setPrice(m_price);
				m.setQuantity(m_qty);
				mList.add(m);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new MobileException("data not found!!");
		}finally{
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return mList;
	}

	public boolean deleteMobile(int mobileid) throws MobileException {
		conn=DbUtil.getConnection();
		String query = "DELETE FROM MOBILES WHERE MOBILEID=?";
		int rec=0;
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1,mobileid);
			rec = pstmt.executeUpdate();
			if(rec>0){
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new MobileException("data not found!!");
		}finally{
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}

	public List<Mobile> searchByRange(double minPrice, double maxPrice) throws MobileException{
		conn=DbUtil.getConnection();
		String query = "SELECT * FROM MOBILES WHERE PRICE>=? AND PRICE<=?";
		List<Mobile> mList = new ArrayList<Mobile>();
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setDouble(1, minPrice);
			pstmt.setDouble(2, maxPrice);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				int m_id = rs.getInt(1);
				String m_name = rs.getString(2);
				double m_price = rs.getInt(3);
				int m_qty = rs.getInt(4);
				Mobile m = new Mobile();
				m.setMobileid(m_id);
				m.setName(m_name);
				m.setPrice(m_price);
				m.setQuantity(m_qty);
				mList.add(m);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new MobileException("data not found!!");
		}finally{
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return mList;
	}

	public boolean updateQty(int mobileid, int qty) throws MobileException {
		conn=DbUtil.getConnection();
		String query = "UPDATE MOBILES SET QUANTITY=QUANTITY-? WHERE MOBILEID=?";
		int rec=0;
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1,qty);
			pstmt.setInt(2, mobileid);
			rec = pstmt.executeUpdate();
			if(rec>0){
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new MobileException("data not found!!");
		}finally{
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}

}


































