package com.cg.mobilePurchaseSystem.dto;

import java.sql.Date;

public class Purchase {
	private int purchaseId;
	private String customer_name;
	private String mail_id;
	private String phone_no;
	private Date purchase_date;
	private int mobileid;
	
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getMail_id() {
		return mail_id;
	}
	public void setMail_id(String mail_id) {
		this.mail_id = mail_id;
	}
	public String getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
	public Date getPurchase_date() {
		return purchase_date;
	}
	public void setPurchase_date(Date purchase_date) {
		this.purchase_date = purchase_date;
	}
	public Purchase() {
		super();
	}
	
	@Override
	public String toString() {
		return "Purchase [purchaseId=" + purchaseId + ", customer_name="
				+ customer_name + ", mail_id=" + mail_id + ", phone_no="
				+ phone_no + ", purchase_date=" + purchase_date + ", mobileid="
				+ mobileid + "]";
	}
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	public Purchase(int purchaseId, String customer_name, String mail_id,
			String phone_no, Date p_date, int mobileid) {
		this.purchaseId = purchaseId;
		this.customer_name = customer_name;
		this.mail_id = mail_id;
		this.phone_no = phone_no;
		this.purchase_date = p_date;
		this.mobileid = mobileid;
	}

}
