package com.cg.mobilePurchaseSystem.ui;


import java.util.Scanner;


import com.cg.mobilePurchaseSystem.dto.Purchase;
import com.cg.mobilePurchaseSystem.exception.MobileException;
import com.cg.mobilePurchaseSystem.service.ImobileService;
import com.cg.mobilePurchaseSystem.service.IpurchaseService;
import com.cg.mobilePurchaseSystem.service.MobileServiceImpl;
import com.cg.mobilePurchaseSystem.service.PurchaseServiceImpl;



public class MobilePurchaseSystem {
	public static void main(String[] args) {
		ImobileService mobileService=new MobileServiceImpl();
		IpurchaseService p = new PurchaseServiceImpl();
		int choice=0;
		Scanner sc=new Scanner(System.in);
		do{
			printDetail();
		
		choice=sc.nextInt();
		switch(choice){
		case 1:try {
				mobileService.showAllMobile();
			} catch (MobileException e) {
				e.printStackTrace();
			}
		break;
		case 2:
			System.out.println("Enter the mobile id you want to delete:");
			int mid = sc.nextInt();
			try {
				mobileService.deleteMobile(mid);
			} catch (MobileException e) {
				e.printStackTrace();
			}
			break;
		case 3:
			System.out.println("Enter the minimum price:");
			int minprice = sc.nextInt();
			System.out.println("Enter the maximum price:");
			int maxprice = sc.nextInt();
			try {
				mobileService.searchByRange(minprice, maxprice);
			} catch (MobileException e) {
				e.printStackTrace();
			}
			break;
		case 4:
			System.out.println("Enter the mobile id you want to delete: ");
			int mobileid = sc.nextInt();
			System.out.println("Enter the quantity of mobile want to update: ");
			int qty = sc.nextInt();
			try {
				mobileService.updateQty(mobileid, qty);
			} catch (MobileException e) {
				e.printStackTrace();
			}
			break;
		case 5:
			System.out.println("Enter the customer name: ");
			String c_name = sc.next();
			System.out.println("Enter the e-mail id of customer: ");
			String e_mail = sc.next();
			System.out.println("Enter the phone no of customer: ");
			String p_no = sc.next();
			System.out.println("Enter the mobile id: ");
			int m_id = sc.nextInt();
			Purchase purchase = new Purchase();
			System.out.println("data taken");
			purchase.setCustomer_name(c_name);
			System.out.println("cname set");
			purchase.setMail_id(e_mail);
			System.out.println("email set");
			purchase.setPhone_no(p_no);
			System.out.println("p no set");
			purchase.setPurchase_date(purchase.getPurchase_date());
			System.out.println("purchase date set");
			purchase.setMobileid(m_id);
			System.out.println("in mobile id");
			try {
				boolean data = p.addPDetails(purchase);
				if(data){
					System.out.println("Welcome User your purchase id is: "+p.getPurchaseid());
				}else{
					System.out.println("Data Not Inserted!!");
				}
			} catch (MobileException e1) {
				e1.printStackTrace();
			}
			break;
		case 6:
			try {
				p.showPurchaseDetails();
			} catch (MobileException e) {
				e.printStackTrace();
			}
		case 7:
			break;
		}
		}while(choice!=7);
	sc.close();
	}
	public static void printDetail(){
		System.out.println("**********");
		System.out.println("1. Show All Mobiles ");
		System.out.println("2. Delete Mobile ");
		System.out.println("3. Search By Range ");
		System.out.println("4. update Quantity of mobile ");
		System.out.println("5. Add purchase details ");
		System.out.println("6. show purchase details ");
		System.out.println("7. Exit");
		System.out.println("***********");
	}
		
}
