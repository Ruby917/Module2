package com.cg.mobilePurchaseSystem.junittest;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobilePurchaseSystem.dao.ImobileDao;
import com.cg.mobilePurchaseSystem.dao.MobileDaoImpl;
import com.cg.mobilePurchaseSystem.exception.MobileException;


public class MobileDaoImplTest {
    ImobileDao iMobile;
	
	@Before
	public void setup(){
		 iMobile = new MobileDaoImpl();
	}
	
	
	@Test
	public void testShowAllMobiles(){
		try {
			assertNotNull(iMobile.showAllMobile());
		} catch (MobileException e) {
			e.printStackTrace();
		}
	}
	
	@After
	public void tearDown(){
		iMobile=null;
	}
	
	

}
