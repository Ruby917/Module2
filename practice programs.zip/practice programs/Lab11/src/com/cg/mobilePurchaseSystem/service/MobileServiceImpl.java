package com.cg.mobilePurchaseSystem.service;

import java.util.List;

import com.cg.mobilePurchaseSystem.dao.ImobileDao;
import com.cg.mobilePurchaseSystem.dao.MobileDaoImpl;
import com.cg.mobilePurchaseSystem.dto.Mobile;
import com.cg.mobilePurchaseSystem.exception.MobileException;

public class MobileServiceImpl implements ImobileService{
	
	ImobileDao imobile = new MobileDaoImpl();

	public List<Mobile> showAllMobile() throws MobileException {
		
		return imobile.showAllMobile();
	}

	public boolean deleteMobile(int mobileid) throws MobileException {
		
		return imobile.deleteMobile(mobileid);
	}

	public List<Mobile> searchByRange(double minPrice, double maxPrice) throws MobileException {
		
		return imobile.searchByRange(minPrice, maxPrice);
	}

	public boolean updateQty(int mobileid, int qty) throws MobileException {
		return imobile.updateQty(mobileid, qty);
	}

}
