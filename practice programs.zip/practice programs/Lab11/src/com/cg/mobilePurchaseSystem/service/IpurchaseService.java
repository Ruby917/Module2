package com.cg.mobilePurchaseSystem.service;

import java.util.List;

import com.cg.mobilePurchaseSystem.dto.Purchase;
import com.cg.mobilePurchaseSystem.exception.MobileException;

public interface IpurchaseService {
	boolean addPDetails(Purchase p) throws MobileException;
	List<Purchase> showPurchaseDetails() throws MobileException;
	public  int getPurchaseid() throws MobileException;

}
