package com.cg.mobilePurchaseSystem.service;

import java.util.List;

import com.cg.mobilePurchaseSystem.dto.Mobile;
import com.cg.mobilePurchaseSystem.exception.MobileException;

public interface ImobileService {
	List<Mobile> showAllMobile() throws MobileException;
	boolean deleteMobile(int mobileid) throws MobileException;
	List<Mobile> searchByRange(double minPrice,double maxPrice) throws MobileException;
	boolean updateQty(int mobileid,int qty) throws MobileException;
}
