package com.cg.mobilePurchaseSystem.service;

import java.util.List;
import java.util.regex.Pattern;


import com.cg.mobilePurchaseSystem.dao.IpurchaseDao;
import com.cg.mobilePurchaseSystem.dao.PurchaseDaoImpl;
import com.cg.mobilePurchaseSystem.dto.Purchase;
import com.cg.mobilePurchaseSystem.exception.MobileException;

public class PurchaseServiceImpl implements IpurchaseService{
	
	IpurchaseDao ipurchase = new PurchaseDaoImpl();
	public boolean addPDetails(Purchase p) throws MobileException {

		return ipurchase.addPurchaseDetails(p);
	}

	public List<Purchase> showPurchaseDetails() throws MobileException {
		
		return ipurchase.showPurchaseDetails();
	}

	public int getPurchaseid() throws MobileException {
		
		return ipurchase.getPurchaseid();
	}
	public void validateCustomerName(String pattern,String cname){
		boolean value=Pattern.matches(pattern,cname);
		if(!value){
			try {
				throw new MobileException("Name should be maximum 20 alphabets out of which first chacter should be upprcase");
			} catch (MobileException e) {
				
				e.printStackTrace();
			}
		}
	}
	public void validateCustomerEmail(String pattern,String email){
		boolean value=Pattern.matches(pattern,email);
		if(!value){
			try {
				throw new MobileException("Email is not valid");
			} catch (MobileException e) {
				
				e.printStackTrace();
			}
		}
	}
	public void validateCustomerPhoneNo(String pattern,String phoneno){
		boolean value=Pattern.matches(pattern,phoneno);
		if(!value){
			try {
				throw new MobileException("phone no should be 10 digit");
			} catch (MobileException e) {
				
				e.printStackTrace();
			}
		}
	}

	
}
