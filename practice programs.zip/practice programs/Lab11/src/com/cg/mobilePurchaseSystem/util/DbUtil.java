package com.cg.mobilePurchaseSystem.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DbUtil {
	public static Properties loadProperty(){
		Properties prop = new Properties();
		InputStream in = null;
		try {
			in = new FileInputStream("oracle.properties");
			try {
				prop.load(in);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}finally{
			try {
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return prop;
	}
	
	
	
	public static Connection getConnection(){
		Connection conn=null;
		Properties prop = loadProperty();
		String url = prop.getProperty("url");
		String driver = prop.getProperty("driver");
		String username = prop.getProperty("username");
		String password = prop.getProperty("password");
		try {
			Class.forName(driver);
			try {
				conn = DriverManager.getConnection(url,username,password);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return conn;
		
	}
	

}
