package com.cg.mobilePurchaseSystem.exception;

public class MobileException extends Exception{
	public MobileException() {
		super();
	}
	public MobileException(String msg) {
		super(msg);
	}
	


}
