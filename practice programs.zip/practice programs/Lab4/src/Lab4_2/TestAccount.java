package Lab4_2;

public class TestAccount {

	public static void main(String[] args){
		int i=0;
		Person smith = new Person("Smith",23);
		Person kathy = new Person("Kathy",22);
		
		Accounts smithAccount = new SavingAccount(8000);
		smithAccount.setAccHolder(smith);
		System.out.println(smithAccount);
		
		Accounts kathyAccount = new CurrentAccount(3000);
		kathyAccount.setAccHolder(kathy);
		System.out.println(kathyAccount);
		
		smithAccount.withdraw(7000);
		kathyAccount.withdraw(5000);
		System.out.println("Updated balance of Smith is :"+smithAccount.getBalance());
		System.out.println("Update balance of Kathy is :"+kathyAccount.getBalance());
	}
}