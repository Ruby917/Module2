package Lab4_2;

public class SavingAccount extends Accounts {
	final public int minimumBalance=500;
	
	public SavingAccount(double balance){
		super(balance);
	}
	public void withdraw(double amt){
		double bal=getBalance();
		if((bal-amt)>=minimumBalance){
			super.withdraw(amt);
			
		}
		else{
			System.out.println("Balance should be minimum of Rs.500");
		}
	}
	
}
