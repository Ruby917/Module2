import java.util.function.Supplier;
public class FactorialMain {

	public static void main(String[] args) {
		Supplier<FacctorialDemo> s1 = FacctorialDemo::new;
		System.out.println(s1.get().calc(6.0));

	}

}
