@FunctionalInterface
public interface Lab14_3Interface {
public boolean validate(String username,String password);
}
