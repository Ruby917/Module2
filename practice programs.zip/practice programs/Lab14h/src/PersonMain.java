import java.util.function.Consumer;
public class PersonMain {

	public static void main(String[] args) {
		//Consumer<Person14_4> s1 = (str)->System.out.println(str);
		Person14_4 p=new Person14_4("Vandana", 22);
		Consumer<Person14_4> s1 = Person14_4::getName;
		s1.accept(p);
		System.out.print((p));
		

	}

	
}
