
@FunctionalInterface
public interface Lab14_1Interface {
	
	public double power(double x,double y);

}

