import java.util.Scanner;


public class Lab14_3Class {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Username:");
		String username=sc.next();
		System.out.println("Enter Password:");
		String password=sc.next();
		Lab14_3Interface imMyObj=(usernam,passwor)->{
			if(usernam.equals("vandana") && passwor.equals("vandana"))
			{
				return true;
			}
			else 
				return false;
			
		};
		boolean flag=imMyObj.validate(username, password);
		if(flag){
			System.out.println("Login successful");
			}
		
	else{
		System.out.println("Invalid Username or password");
	}
sc.close();
}
}
