
public class Lab14_1Class {

	public static void main(String[] args) {
		Lab14_1Interface im= (x,y) -> Math.pow(x, y);
		double result=im.power(5,3);
		System.out.println("Value of x is 5");
		System.out.println("Value of y is 3");
		System.out.println("x^y is "+result);
		}

}
