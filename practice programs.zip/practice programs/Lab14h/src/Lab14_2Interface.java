@FunctionalInterface
public interface Lab14_2Interface {
	public String addSpace(String input);
	

}
