package com.cg.emplmgmt.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegxDemo {
	public static void main(String[] args) {
		String s = "aghjg";
		//String pattern = "^[1-9]{3}[_|\\s][0-9]{4}_[0-9]{3}$";
		//String pattern = "(?=^.{1,}$)(?!.*\\s)[0-9a-zA-Z!@#$%*()_+^&]*$";
		//String pattern = ".[*\\S]";
		String pattern = "[0-9a-zA-Z]+";
		Pattern r = Pattern.compile(pattern);
		Matcher m = r.matcher(s);
		System.out.println(m.matches());
	}

}
