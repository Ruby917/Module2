package com.cg.emplmgmt.util;

import java.util.ArrayList;

public class EvenThread extends Thread{
	ArrayList<Integer> aList;
	public EvenThread(ArrayList<Integer> aList){
		this.aList = aList;
	}
	
	
	public void run(){
		for(int i = 0; i<=10;i++){
			if(i%2==0){
				aList.add(i);
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
