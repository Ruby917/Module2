package com.cg.emplmgmt.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JdbcTest {
	public static void main(String[] args) {
		Connection conn=null;
		PreparedStatement stmt=null;
		try {
			conn = JDBCUtilClass.getConnection();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		
		if(conn !=null){
			
			System.out.println("connected");
		
			String inserquery = "insert into department_masters values(?,?)";
			try {
				stmt = conn.prepareStatement(inserquery);
				
				stmt.setInt(1, 60);
				stmt.setString(2, "INFORMATION TECHNOLOGY");
				int rec = stmt.executeUpdate();
				System.out.println(rec);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
