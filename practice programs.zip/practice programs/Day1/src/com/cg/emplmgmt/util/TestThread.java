package com.cg.emplmgmt.util;

import java.util.ArrayList;

public class TestThread {
	public static void main(String[] args) {
		ArrayList<Integer> aList = new ArrayList<Integer>();
		EvenThread even = new EvenThread(aList);
		OddThread odd = new OddThread(aList);
		even.start();
		odd.start();
		try {
			even.join();
			odd.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(aList);
	}

}
