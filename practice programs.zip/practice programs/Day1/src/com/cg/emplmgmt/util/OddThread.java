package com.cg.emplmgmt.util;

import java.util.ArrayList;

public class OddThread extends Thread{
	ArrayList<Integer> aList;
	public OddThread(ArrayList<Integer> aList){
		super();
		this.aList = aList;
	}
	
	
	public void run(){
		for(int i = 0; i<=10;i++){
			if(i%2!=0){
				aList.add(i);
			}
		}
	}


}
