package com.cg.emplmgmt.util;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class CollableDemo {
	public static void main(String[] args) {
		Connection conn= null;
		CallableStatement cst = null;
		String query = "{call GETDEPT(?,?)}";
		conn = JDBCUtilClass.getConnection();
		try {
			cst=conn.prepareCall(query);
			cst.setInt(1, 20);
			cst.registerOutParameter(2, java.sql.Types.VARCHAR);
			cst.execute();
			String dept_name = cst.getString(2);
			System.out.println(dept_name);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
