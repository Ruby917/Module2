import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class DeleteJDBC {
	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		String url = "jdbc:oracle:thin:@10.125.6.62:1521:orcl11g";
	try(Connection conn = DriverManager.getConnection(url,"labg104trg26","labg104oracle")){
		if(conn!=null){
			System.out.println("connected");
			Statement st = conn.createStatement();
			int rs = st.executeUpdate("delete from department_masters where dept_code=60");
			
		}
	}catch(SQLException e){
		System.out.println(e);
	}

}

}
