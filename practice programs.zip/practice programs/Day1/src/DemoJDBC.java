import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;


public class DemoJDBC {
	public static void main(String[] args) {
		writeProperties();
		loadProperties("oracle.properties");
	}
	public static void writeProperties(){
		Properties prop = new Properties();
		OutputStream output = null;
		try {
			output = new FileOutputStream("oracle.properties");
			prop.setProperty("url","jdbc:oracle:thin:@192.168.12.16:1521:oracle8i");
			prop.setProperty("driver", "oracle.jdbc.driver.OracleDriver");
			prop.setProperty("username", "labg104trg26@orcl11g");
			prop.setProperty("password", "labg104oracle");
			try {
				output.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			try {
				prop.store(output, null);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
	}
	public static void loadProperties(String fileName) {

		InputStream propsFile;
		Properties prop = new Properties();

		try {
			propsFile = new FileInputStream(fileName);
			prop.load(propsFile);
			System.out.println(prop.getProperty("url"));
			System.out.println(prop.getProperty("driver"));
			System.out.println(prop.getProperty("username"));
			System.out.println(prop.getProperty("password"));
			propsFile.close();
		} catch (IOException ioe) {
			System.out.println("I/O Exception.");
			ioe.printStackTrace();
			System.exit(0);
		}
	}

}
