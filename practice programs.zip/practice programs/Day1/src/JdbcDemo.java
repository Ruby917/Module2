import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;


public class JdbcDemo {
	
	public void loadProperty(){
		Properties prop = new Properties();
		
	}
	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		String url = "jdbc:oracle:thin:@10.125.6.62:1521:orcl11g";
	try(Connection conn = DriverManager.getConnection(url,"labg104trg26","labg104oracle")){
		if(conn!=null){
			System.out.println("connected");
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from Department_masters");
			while(rs.next()){
				/*int dept_code = rs.getInt(1);
				String dept_name = rs.getString(2);
				System.out.println(dept_code+" "+dept_name);*/
				System.out.println(rs.getString(1)+" "+rs.getString(2));
			
			}
		}
	}catch(SQLException e){
		System.out.println(e);
	}

}
}