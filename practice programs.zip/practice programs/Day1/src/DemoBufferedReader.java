import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;


public class DemoBufferedReader {
	public static void main(String[] args) {
		try {
			BufferedReader in =  new BufferedReader(new FileReader("d:\\wordcount.txt"));
			LineNumberReader lr = new LineNumberReader(in);
			String line;
			try {
				while((line = lr.readLine()) != null)
					System.out.println(lr.getLineNumber()+" " +line);
				while((line=in.readLine())!=null){
					System.out.println(line);
				}
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

}
