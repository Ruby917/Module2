
public class Product {
	private int pno;
	private String pname;
	private int qty;
	private double price;
	public Product(int pno, String pname, int qty, double price) {
		super();
		this.pno = pno;
		this.pname = pname;
		this.qty = qty;
		this.price = price;
	}
	public Product() {
		super();
	}
	public double calculateCost(){
		//with 10% discount
		double cost = qty * price;
		cost  = cost - (cost*0.1);
	    return cost;
	}
	public Product get(){
		Product p = new Product();
		return p;
	}

}
