import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;


@RunWith(Parameterized.class)
public class CalculatorTest {

	 @Parameterized.Parameters
     public static Collection data()
     {
         return Arrays.asList(new Object[][] {{2,4,6}, {78,22,100}, {50,50,100}, {10, 10,20},{5,20,25}});
     }

	 private int input1;
	 private int input2;
     private int expected;

     public CalculatorTest(int input1,int input2, int expected)
     {
         this.input1 = input1;
         this.input2 = input2;
         this.expected = expected;
     }
     @Test
     //(expected=ArithmeticException.class)
     public void testMethod()
     {
     	System.out.println("Running parameterized tests");
      //   Assert.assertEquals("Test failed",expected, Calculator.squared(input));
         Assert.assertEquals(expected, Calculator.add(input1,input2));
     }
}
