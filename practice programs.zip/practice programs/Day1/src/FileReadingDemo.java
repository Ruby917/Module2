import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class FileReadingDemo {
	public static void main(String[] args) {
		/*try(FileInputStream in = new FileInputStream("d:\\wordcount.txt");) {
			int ch;
			while((ch =in.read())!=-1){
				System.out.print((char)ch);
			}
			
			
			int ch=in.read();
			while(ch!=-1){
				System.out.print((char)ch);
				ch=in.read();
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}*/
		try(FileReader in = new FileReader("d:\\wordcount.txt");) {
			int ch;
			while((ch =in.read())!=-1){
				System.out.print((char)ch);
			}
			
			/*
			int ch=in.read();
			while(ch!=-1){
				System.out.print((char)ch);
				ch=in.read();
			}*/
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

}
