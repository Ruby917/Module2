
public class DemoVargs {

	public static void main(String ... args) {
		add(1,2);
		add(1,2,3,4,5,6);
		add(1,6,7);
		for(String s:args){
			System.out.println(s);
		}
	}

	private static void add(int ... a) {
		int result=0;
		for(int i = 0;i<a.length;i++){
			result+=a[i];
		}
		System.out.println(result);
		
	}

}
