import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class ProductTest {
	Product p,p1;

	@Before
	public void setUp() throws Exception {
	  p = new Product(1,"pen",10,10);
	  p1=p;
	}

	@After
	public void tearDown() throws Exception {
		p=null;
	}

	@Test
	public void testCalculateCost() {
		assertEquals(90.0,p.calculateCost(),0.0);
	}
	
	@Test
	public void testGet(){
		assertNotNull(p.get());
	}
	@Test
	public void testSame(){
		assertSame(p,p1);
	}

}
