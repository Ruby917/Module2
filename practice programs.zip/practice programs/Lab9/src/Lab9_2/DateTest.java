package Lab9_2;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class DateTest {

	@Test
	public void testSetDay() {
		assertTrue(true);
		
	}
	@Test
	public void testGetDay() {
		assertTrue(true);
	}

	@Test
	public void testSetMonth() {
		assertTrue(true);
	}

	@Test
	public void testGetMonth() {
		assertTrue(true);
	}

	@Test
	public void testSetYear() {
		assertTrue(true);
	}

	@Test
	public void testGetYear() {
		assertTrue(true);
		
	}

}
