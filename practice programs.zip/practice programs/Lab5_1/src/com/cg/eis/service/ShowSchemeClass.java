package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class ShowSchemeClass implements ShowSchemeInterface {
	Employee emp ;
	public void inputDetails() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Id: ");
		int id = sc.nextInt();
		System.out.println("Enter the Name: ");
		String name = sc.next();
		System.out.println("Enter the Salary: ");
		int salary = sc.nextInt();
		System.out.println("Enter the Designation: ");
		String designation = sc.next();
	    emp = new Employee(id,name,salary,designation);
	}
	public void showScheme(){
		String insuranceScheme=null;
		double salary = emp.getSalary();
		String designation = emp.getDesignation();
		if((salary>5000 && salary<20000) && designation.equals("System Associate")){
			insuranceScheme = "Scheme C";
		}
		else if((salary>=20000 && salary<40000) && designation.equals("Programmer")){
			insuranceScheme = "Scheme B";		
			}
		else if(salary>=40000 && designation.equals("Manager")){
			insuranceScheme = "Scheme A";			
			}
		else if(salary<5000 && designation.equals("Clerk")){
			insuranceScheme = "No Scheme";			
			}
		emp.setInsuranceScheme(insuranceScheme);
	}

	public void displayDetails() {
		System.out.println("---------Employee Details-------");
		System.out.println("Employee Id: "+emp.getId());
		System.out.println("Employee Name: "+emp.getName());
		System.out.println("Employee Salary: "+emp.getSalary());
		System.out.println("Employee Designation: "+emp.getDesignation());
		System.out.println("Employee Insurance Scheme: "+emp.getInsuranceScheme());
	}


}
