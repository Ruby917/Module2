package com.cg.eis.service;

public interface ShowSchemeInterface {
	public void inputDetails();
	public void showScheme();
    public void displayDetails();
}
