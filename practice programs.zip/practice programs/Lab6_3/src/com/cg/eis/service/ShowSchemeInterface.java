package com.cg.eis.service;

import com.cg.eis.exception.EmployeeException;

public interface ShowSchemeInterface {
	public void inputDetails() throws EmployeeException;
	public void showScheme();
    public void displayDetails();
}
