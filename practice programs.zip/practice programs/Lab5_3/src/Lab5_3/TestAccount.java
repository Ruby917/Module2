package Lab5_3;

public class TestAccount {

	public static void main(String[] args) {
		
		Person smith = new Person("Smith",23);
		Person kathy = new Person("Kathy",21);
	   
		
		Accounts smithAccount = new SavingAccount(2000);
		smithAccount.setAccHolder(smith);
		System.out.println(smithAccount);
		
		Accounts kathyAccount = new CurrentAccount(3000);
		kathyAccount.setAccHolder(kathy);
		System.out.println(kathyAccount);
		
		smithAccount.deposit(2000);
		kathyAccount.withdraw(2000);
		System.out.println("Updated Balance of Smith "+smithAccount.getBalance());
		System.out.println("Updated Balance of Kathy "+kathyAccount.getBalance());

	}

}