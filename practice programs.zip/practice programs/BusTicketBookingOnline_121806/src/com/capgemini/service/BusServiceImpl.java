package com.capgemini.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.exception.BookingException;

public class BusServiceImpl implements BusService{
	BusDao busDao = new BusDaoImpl();

	public ArrayList<BusBean> retrieveBusDetails() {
		return busDao.retrieveBusDetails();
	}

	public int bookTicket(BookingBean bookingBean) throws BookingException {
		return busDao.bookTicket(bookingBean);
	}
	public int validateCustomerId(String patt,String c_id) throws BookingException{
		boolean value=Pattern.matches(patt,c_id);
		int flag = 0;
		if(!value){
			flag =0;
			throw new BookingException("Customer Id is not in proper format");
		}else{
			flag = 1;
		}
		return flag;
	}
	
}
