package com.capgemini.exception;


public class BookingException extends Exception{
	public BookingException() {
		super();
	}
	public BookingException(String msg) {
		super(msg);
	}
	

}
