package com.capgemini.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;

public class RetrieveBusDetailsTest {
BusDao busDao = null;
	
	
	@Before
	public void setUp() throws Exception {
		busDao = new BusDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		busDao = null;
	}

	@Test
	public void test() {
		assertNotNull(busDao.retrieveBusDetails());
	}
}
