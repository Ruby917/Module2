package com.capgemini.client;

import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;
import com.capgemini.service.BusService;
import com.capgemini.service.BusServiceImpl;

public class MainClient {
	private static final Logger mylogger=Logger.getLogger(MainClient.class);
	public static void main(String[] args) {
		mylogger.info("Application started");
		BusService busService = new BusServiceImpl();
		int choice=0;
		Scanner sc=new Scanner(System.in);
		do{
			printDetail();
		System.out.println("Enter your Choice: ");
		choice=sc.nextInt();
		switch(choice){
		case 1:
			ArrayList<BusBean> arrayList = null;
			arrayList = busService.retrieveBusDetails();
			System.out.println("----------Bus Deatils------");
			for(BusBean busBean:arrayList){
				System.out.println("bus Id : "+busBean.getBusId());
				System.out.println("Bus Type : "+busBean.getBusType());
				System.out.println("From Stop : "+busBean.getFromStop());
				System.out.println("To Stop : "+busBean.getToStop());
				System.out.println("Fare : "+busBean.getFare());
				System.out.println("Available Seats : "+busBean.getAvailableSeats());
				System.out.println("Date of journey : "+busBean.getDateOfJourney());
				System.out.println("--------------------------------");
			}
			System.out.println("Book Ticket");
			String custidpatt = "[A-Z]{1}[0-9]{6}";
			System.out.println("Enter Customer Id : ");
			String c_id = sc.next();

			try {
				int val = busService.validateCustomerId(custidpatt, c_id);
				if(val==1){
					System.out.println("Please Enter The Bus Id : ");
					int bus_id = sc.nextInt();
					System.out.println("Enter the Number of seats : ");
					int noOfseats = sc.nextInt();

					BookingBean bookingBean = new BookingBean();
					bookingBean.setCustId(c_id);
					bookingBean.setBusId(bus_id);
					bookingBean.setNoOfSeats(noOfseats);
					try {
						busService.bookTicket(bookingBean);
					} catch (BookingException e) {
						e.printStackTrace();
					}

				}else{
					System.out.println("Please Enter cutomer id in correct format");
				}
			} catch (BookingException e1) {
				e1.printStackTrace();
			}
			
			break;
		case 2:System.out.println("Succefully Exited Application");
		mylogger.info("Application Ended");
			break;
		}
		}while(choice!=2);
		sc.close();
		
	}
	
	public static void printDetail(){
		System.out.println("**********");
		System.out.println("1. Book Ticket ");
		System.out.println("2. Exit ");
		System.out.println("***********");
	}

}
