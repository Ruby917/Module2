package Lab3;

import java.util.Scanner;

public class Lab3_1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string:");
		String str = sc.nextLine();
		System.out.println("Enter 1:To add string to itself");
		System.out.println("Enter 2:To replace odd positions with #");
		System.out.println("Enter 3: To remove duplicate characters in the string");
		System.out.println("Enter 4: To change odd characters to upper case");
		int ch=sc.nextInt();
		switch(ch){
		case 1:toAppend(str);
			break;
		case 2:toReplace(str);
			break;
		case 3:toRemoveDuplicate(str);
			break;
		case 4:toUppercase(str);
			
		}
	}
	public static void toAppend(String str){
		System.out.println("Appended string to itself:"+str+str);
	}
	public static void toReplace(String str){
		for (int i=0; i < str.length(); i++){
	        if (i % 2 != 0){
	          str = str.substring(0,i-1) + "#" + str.substring(i, str.length());
	        }
	    }
	      System.out.println("String after replacing odd positions with #"+str);
	}
	public static void toRemoveDuplicate(String str){
		String rdup = "";
	       for (int i = 0; i< str.length(); i++) {
	           int count = 1;
	           for (int j = 0; j < rdup.length(); j++) {
	               if (str.charAt(i) == rdup.charAt(j)){
	                    count++;
	               }
	               
	           }
	           if (count == 1){
	               rdup += str.charAt(i);
	               }
	           }
	            
	           System.out.print("String after removing duplicate element:"+rdup);
		
	}
	public static void toUppercase(String str){
		String s = new String();
		for(int i=0;i<str.length();i++){
			char ch = str.charAt(i);
			if(i%2==0){
				ch=Character.toUpperCase(ch);
			}
			s+=ch;
		}
		System.out.println("String after changing odd characters to upper case: "+s);
	}

}
