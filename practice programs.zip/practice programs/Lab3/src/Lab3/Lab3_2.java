package Lab3;

import java.util.Scanner;

public class Lab3_2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string:");
		String str = sc.nextLine();
		isPositiveString(str);
		}
	public static void isPositiveString(String str){
		int count=1;;
		for (int i = 0; i< str.length(); i++){
			count=1;
			for(int j=1;j<str.length();j++){
				char ch1 = str.charAt(i);
	       	    int ascii1 = (int) ch1;
	       	    char ch2 = str.charAt(j);
	       	    int ascii2 = (int) ch2;
	            if(ascii1<ascii2){
	            	count = 0;
	            } 
			}
        	
         }
		 if(count==1){
			 System.out.println("positive string");
		 }
		 else{
			 System.out.println("not positive string");
		 }
		
	}
}


