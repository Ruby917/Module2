package Lab3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Lab3_3 {
	public static void calculatePeriod(String sdate){
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate givenDate = LocalDate.parse(sdate,formatter);
		System.out.println(givenDate);
		LocalDate today = LocalDate.now();
		Period period = givenDate.until(today);
		System.out.println("Days: "+period.getDays()+" Months: "+period.getMonths()+" year: "+period.getYears());
		
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the date: ");
		String sdate= sc.next();
		calculatePeriod(sdate);
		
	}

}
