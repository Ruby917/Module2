package Lab3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;



public class Lab3_7 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First Name:");
		String fName = sc.nextLine();
		System.out.println("Enter Last Name:");
		String lName = sc.nextLine();
		System.out.println("Enter the date of birth:");
		String bdate = sc.nextLine();
		calAge(bdate);
		getFullName(fName,lName);
	}

	private static void getFullName(String fName, String lName) {
		System.out.println("Full Name of the person is:"+fName+" "+lName);
		
	}

	private static void calAge(String bdate) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate birthDate = LocalDate.parse(bdate,formatter);
		System.out.println(birthDate);
		LocalDate today = LocalDate.now();
		Period period = birthDate.until(today);
		System.out.println("Age of the person is: "+period.getYears());
		
	}
}
