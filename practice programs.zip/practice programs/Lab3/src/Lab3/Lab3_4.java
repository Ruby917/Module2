package Lab3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Lab3_4 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first date: ");
		String fdate= sc.next();
		System.out.println("Enter the second date: ");
		String sdate= sc.next();
		calculateDifference(fdate,sdate);
	}

	private static void calculateDifference(String fdate, String sdate) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate firstDate = LocalDate.parse(fdate,formatter);
		LocalDate secondDate = LocalDate.parse(sdate,formatter);
		Period period = firstDate.until(secondDate);
		System.out.println("The Difference between the two dates are: "+"Days: "+period.getDays()+" Months: "+period.getMonths()+" year: "+period.getYears());
	}

}
